require("dotenv").config();
const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors());

// Database connection
const db = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME
});

db.connect(err => {
    if (err) {
        console.error("Database connection error:", err);
        process.exit(1);
    }
    console.log("Connected to MySQL database");
});

// Get all text entries
app.get("/entries", (req, res) => {
    db.query("SELECT * FROM text_entries", (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// Add a new text entry
app.post("/entries", (req, res) => {
    const { user_id, content } = req.body;
    if (!user_id || !content) {
        return res.status(400).json({ error: "User ID and content are required" });
    }

    db.query("INSERT INTO text_entries (user_id, content) VALUES (?, ?)", 
        [user_id, content], 
        (err, result) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ message: "Entry added", id: result.insertId });
        }
    );
});

// Update a text entry
app.put("/entries/:id", (req, res) => {
    const { content } = req.body;
    if (!content) {
        return res.status(400).json({ error: "Content is required" });
    }

    db.query("UPDATE text_entries SET content = ? WHERE id = ?", 
        [content, req.params.id], 
        (err, result) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ message: "Entry updated" });
        }
    );
});

// Delete a text entry
app.delete("/entries/:id", (req, res) => {
    db.query("DELETE FROM text_entries WHERE id = ?", 
        [req.params.id], 
        (err, result) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ message: "Entry deleted" });
        }
    );
});

app.listen(5000, () => console.log("Server running on port 5000"));
