import { useState, useEffect } from "react";
import axios from "axios";

function App() {
    const [entries, setEntries] = useState([]);
    const [content, setContent] = useState("");

    // Fetch all text entries
    const fetchEntries = () => {
        axios.get("http://localhost:5000/text_entries").then((response) => {
            setEntries(response.data);
        }).catch(error => console.error("Error fetching entries:", error));
    };

    useEffect(() => {
        fetchEntries();
    }, []);

    // Add a new text entry
    const addEntry = () => {
        if (!content.trim()) return;
        axios.post("http://localhost:5000/text_entries", { user_id: 1, content })
            .then(() => {
                setContent("");
                fetchEntries(); // Refresh the list after adding
            })
            .catch(error => console.error("Error adding entry:", error));
    };

    // Delete a text entry
    const deleteEntry = (id) => {
        axios.delete(`http://localhost:5000/text_entries/${id}`)
            .then(() => fetchEntries()) // Refresh the list after deleting
            .catch(error => console.error("Error deleting entry:", error));
    };

    return (
        <div>
            <h1>Text Entries</h1>
            <input 
                type="text" 
                value={content} 
                onChange={(e) => setContent(e.target.value)} 
                placeholder="Enter text..."
            />
            <button onClick={addEntry}>Add Entry</button>
            <ul>
                {entries.map(entry => (
                    <li key={entry.id}>
                        {entry.content} 
                        <button onClick={() => deleteEntry(entry.id)}>Delete</button>
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default App;
